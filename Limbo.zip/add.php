<?php

    // Established a network to the database
    include("connectionSql.php");


    // Set the Values all to empty
    $fname = $lname = $email = $contact_email = $phone = $address = $city = $state = $country = $checkin_date = $checkout_date = $postcode = "";

    // Set array that will saves the errors
    $errors = array('fname' => '', 'lname'=>'', 'email'=>'', 'contact_email'=>'', 'phone'=>'', 'address'=>'', 'city'=>'', 'state'=>'', 'postcode'=>'', 'country'=>'', 'checkin_date'=>'', 'checkout_date'=>'');


    if(isset($_POST['submit'])){
        // First Name
        if(empty($_POST['first_Name'])){
            $errors['fname'] = "First Name should not be empty <br/>";
        } else {
            $fname = htmlspecialchars($_POST['first_Name']);
            if (!preg_match('/^[a-zA-Z\s]+$/', $fname)) {
                $errors['fname'] = "First Name should be letters and spaces only <br/>";
            };
        };

        // Last Name
        if(empty($_POST['last_Name'])){
            $errors['lname'] = "Last Name should not be empty <br/>";
        } else {
            $lname = htmlspecialchars($_POST['last_Name']);
            if (!preg_match('/^[a-zA-Z\s]+$/', $lname)) {
                $errors['lname'] = "Last Name should be letters and spaces only <br/>";
            }
        };


        // Email
        if(empty($_POST['email'])){
            $errors['email'] = "Email should not be empty <br/>";
        } else {
            $email = htmlspecialchars($_POST['email']);
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                $errors['email'] = "Should be a valid email <br/>";
            };
        };

        // Contact Email
        if(empty($_POST['contact_email'])){
            $errors['contact_email'] = "Email should not be empty <br/>";
        } else {
            $contact_email = htmlspecialchars($_POST['contact_email']);
            if(!filter_var($contact_email, FILTER_VALIDATE_EMAIL)){
                $errors['contact_email'] = "Should be a valid email <br/>";
            };
        };

        // Phone
        if(empty($_POST['phone'])){
            $errors['phone'] = "Phone should not be empty <br/>";
        } else {
            $phone = htmlspecialchars($_POST['phone']);
            if ($phone < 11) {
                $errors['phone'] = "Phone should be atleast 11 numbers only <br/>";
            } else if ($phone > 11) {
                $errors['phone'] = "Phone should not be greater than 11 numbers <br/>";
            }
        };

        // Address
        if(empty($_POST['address'])){
            $errors['address'] = "Address should not be empty <br/>";
        } else {
            $address = htmlspecialchars($_POST['address']);
            if (!preg_match('/^[0-9]+$/', $address)) {
                $errors['address'] = "Address should be numbers letters spaces only <br/>";
            }
        };

        // City 
        if(empty($_POST['city'])){
            $errors['city'] = "City should not be empty <br/>";
        } else {
            $city = htmlspecialchars($_POST['city']);
            if (!preg_match('/^[a-zA-Z\s]+$/', $city)) {
                $errors['city'] = "City should be letters and spaces only <br/>";
            }
        };

        // State
        if(empty($_POST['state'])){
            $errors['state'] = "State should not be empty <br/>";
        } else {
            $state = htmlspecialchars($_POST['state']);
            if (!preg_match('/^[a-zA-Z\s]+$/', $state)) {
                $errors['state'] = "State should be letters and spaces only <br/>";
            }
        };

        // Postcode
        if(empty($_POST['postcode'])){
            $errors['postcode'] = "Numbers should not be empty <br/>";
        } else {
            $postcode = htmlspecialchars($_POST['postcode']);
            if (strlen($postcode) < 4) {
                $errors['postcode'] = "Postcode should be atleast 4-5 numbers only <br/>";
            } else if (strlen($postcode) > 5) {
                $errors['postcode'] = "Phone should not be greater than 4-5 numbers <br/>";
            }
        };

        // Country
        if(empty($_POST['country'])){
            $errors['country'] = "Country should not be empty <br/>";
        } else {
            $country = htmlspecialchars($_POST['country']);
            if (!preg_match('/^[a-zA-Z\s]+$/', $country)) {
                $errors['country'] = "Country should be letters and spaces only <br/>";
            }
        };

        // Checkin
        if(empty($_POST['checkin_date'])){
            $errors['checkin_date'] = "Checkin Date should not be empty <br/>";
        } else {
            $checkin_date = htmlspecialchars($_POST['checkin_date']);
        };

        // CheckOut
        if(empty($_POST['checkout_date'])){
            $errors['checkout_date'] = "Checkout Date should not be empty <br/>";
        } else {
            $checkout_date = htmlspecialchars($_POST['checkout_date']);
        };


        // // Inserting the data to the Database
        // $insert = "INSERT INTO tbl_reservation (First_Name, Last_Name, Email, Contact_Email, Phone, Address, City, State, Post_Code,Country, Checkin_Date, Checkout_Date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        // $param = array(&$fname, &$Lname, &$Email, &$contact_email, &$phone, &$address, &$city, &$state, &$postcode, &$country, &$checkin_date, &$checkin_date);
        // sqlsrv_query($conn, $insert, $param);

        // sqlsrv_close($conn);


        if(array_filter($errors)){
            // echo 'errors in forms';
        } else {
            // echo 'form is valid';
            header('Location: connectionSql.php');
        };
    };




?>

<!DOCTYPE html>
<html lang="en">

    <?php include('templates/header.php');?>

    <section id="contact" class="container my-3">
        <div class="container-lg my-7">
            <h2>Get in Touch</h2>
            <p class="lead">Questions to ask?Fill out the form the form to contact me directly ...</p>
            <div class="container row align-items-start">
                <!-- Form will be place -->
                <div class="col">
                    <div class="guest-details mb-4">
                        <div class="accordion" id="accordionDetails">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                        Your Details
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionPayment">
                                    <form method="post" action="add.php">
                                        <!-- A row with two columns, for the first and last name fields -->
                                        <div class="row m-3">
                                            <!-- The first name field -->
                                            <div class="col">
                                                <!-- The label for the first name field -->
                                                <label for="first_Name" class="form-label">First Name</label>
                                                <!-- The first name input field -->
                                                <input type="text" class="form-control" id="first_Name" aria-describedby="emailHelp" name="first_Name" value="<?php echo $fname; ?>">
                                                <div class="text-danger"><?php echo $errors['fname'] ?></div>
                                            </div>
                                            <!-- The last name field -->
                                            <div class="col">
                                                <!-- The label for the last name field -->
                                                <label for="last_Name" class="form-label">Last Name</label>
                                                <!-- The last name input field -->
                                                <input type="text" class="form-control" id="last_Name" aria-describedby="emailHelp" name="last_Name" value="<?php echo $lname; ?>">
                                                <div class="text-danger"><?php echo $errors['lname'] ?></div>
                                            </div>
                                        </div>
                                        <!-- A row with two columns, for the email and contact email fields -->
                                        <div class="row m-3">
                                            <!-- The email field -->
                                            <div class="col">
                                                <!-- The label for the email field -->
                                                <label for="email" class="form-label">Email</label>
                                                <!-- The email input field -->
                                                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" value="<?php echo $email; ?>">
                                                <div class="text-danger"><?php echo $errors['email'] ?></div>
                                            </div>
                                            <!-- The contact email field -->
                                            <div class="col">
                                                <!-- The label for the contact email field -->
                                                <label for="contact_email" class="form-label">Contact Email</label>
                                                <!-- The contact email input field -->
                                                <input type="email" class="form-control" id="contact_email" aria-describedby="emailHelp" name="contact_email" value="<?php echo $contact_email; ?>">
                                                <div class="text-danger"><?php echo $errors['contact_email'] ?></div>
                                            </div>
                                        </div>

                                        <!-- A row with two columns, for the address and additional address fields -->
                                        <div class="row m-3">
                                            <!-- The address field -->
                                            <div class="col">
                                                <!-- The label for the address field -->
                                                <label for="address" class="form-label">Address</label>
                                                <!-- The address input field -->
                                                <input type="text" class="form-control" id="address" aria-describedby="emailHelp" name="address" value="<?php echo $address; ?>">
                                                <div class="text-danger"><?php echo $errors['address'] ?></div>
                                            </div>
                                            <!-- The Phone field -->
                                            <div class="col">
                                                <!-- The label for the email field -->
                                                <label for="email" class="form-label">Phone</label>
                                                <!-- The email input field -->
                                                <input type="number" class="form-control" id="phone" aria-describedby="emailHelp" name="phone" value="<?php echo $phone; ?>">
                                                <div class="text-danger"><?php echo $errors['phone'] ?></div>
                                            </div>
                                        </div>
                                        <!-- A row with two columns, for the city and state fields -->
                                        <div class="row m-3">
                                            <!-- The city field -->
                                            <div class="col">
                                                <!-- The label for the city field -->
                                                <label for="city" class="form-label">City</label>
                                                <!-- The city input field -->
                                                <input type="text" class="form-control" id="city" aria-describedby="emailHelp" name="city" value="<?php echo $city; ?>">
                                                <div class="text-danger"><?php echo $errors['city'] ?></div>
                                            </div>
                                            <!-- The state field -->
                                            <div class="col">
                                                <!-- The label for the state field -->
                                                <label for="state" class="form-label">State</label>
                                                <!-- The state input field -->
                                                <input type="text" class="form-control" id="state" aria-describedby="emailHelp" name="state" value="<?php echo $state; ?>">
                                                <div class="text-danger"><?php echo $errors['state'] ?></div>
                                            </div>
                                        </div>
                                        <!-- A row with two columns, for the country and postcode fields -->
                                        <div class="row m-3">
                                            <!-- The country field -->
                                            <div class="col">
                                                <!-- The label for the country field -->
                                                <label for="country" class="form-label">Country</label>
                                                <!-- The country input field -->
                                                <input type="text" class="form-control" id="country" aria- describedby="emailHelp" name="country" value="<?php echo $country; ?>">
                                                <div class="text-danger"><?php echo $errors['country'] ?></div>
                                            </div>
                                            <!-- The postcode field -->
                                            <div class="col">
                                                <!-- The label for the postcode field -->
                                                <label for="postcode" class="form-label">Postcode</label>
                                                <!-- The postcode input field -->
                                                <input type="number" class="form-control" id="postcode" aria-describedby="emailHelp" name="postcode" value="<?php echo $postcode; ?>">
                                                <div class="text-danger"><?php echo $errors['postcode'] ?></div>
                                            </div>
                                        </div>
                                        <!-- A row with one column, for the checkout date field -->
                                        <div class="row m-3">
                                            <div class="col">
                                                <!-- The label for the checkout date field -->
                                                <label for="checkout_date" class="form-label">CheckIn Date</label>
                                                <!-- The checkout date input field -->
                                                <input type="date" class="form-control" id="checkin_date" aria-describedby="emailHelp" name="checkin_date" value="<?php echo $checkin_date; ?>">
                                                <div class="text-danger"><?php echo $errors['checkin_date'] ?></div>
                                            </div>


                                            <!-- The checkout date field -->
                                            <div class="col">
                                                <!-- The label for the checkout date field -->
                                                <label for="checkout_date" class="form-label">Checkout Date</label>
                                                <!-- The checkout date input field -->
                                                <input type="date" class="form-control" id="checkout_date" aria-describedby="emailHelp" name="checkout_date" value="<?php echo $checkout_date; ?>">
                                                <div class="text-danger"><?php echo $errors['checkout_date'] ?></div>
                                            </div>
                                        </div>
                                        <!-- The form submit button -->

                                        <div class="row m-3">
                                            <!-- The checkout date field -->
                                            <div class="col">
                                                <button type="submit" class="btn btn-primary" id="submitButton" name="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include('templates/footer.php'); ?>

</html>